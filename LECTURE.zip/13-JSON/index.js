// JSON
const car = `{
    "model": "IONIQ 5",
    "company": "HYUNDAI",
    "price": 50000000,
    "year": 2023,
    "isElectricCar": true,
    "options": ["side mirror", "smart sensor", "built-in cam"]
}`;
// + 후행쉼표 - 마지막 원소에 , 붙이는 JSON에선 그러면 안됨 (에러 뜸)

console.log(car); // format: JSON

// 역직렬화: JSON.parse() -> 통신하여 받은 데이터를 객체로 변환
// json to js obj
const obj = JSON.parse(car);
console.log(obj); // js obj

// obj 변수는 js object이므로 .(dot)/[] 연산자를 이용해 키 값에 접근 가능
console.log(obj.model); // IONIQ 5
console.log(obj.price); // 50000000
console.log(obj.hello); // undefined (hello라는 키 값이 존재하지 않으므로)

// 직렬화: JSON.stringify() -> 통신하기 쉬운 포맷(JSON)으로 변환
// js obj to json
const json = JSON.stringify(obj);
console.log(json, typeof json);

// json 변수는 JSON 형태의 "문자열(string)"이므로 
// .(dot)/[] 연산자를 이용해서 키 값에 접근이 불가능
console.log(json.model); // undefined
console.log(json.price); // undefined
console.log(json.hello); // undefined

//  더이상 obj가 아님. 

// json 변수는 string 타입이므로 
// string 타입에 쓸 수 있는 내장 메소드들은 쓸 수 있음!
console.log(json.split(""));
console.log(json.toUpperCase());