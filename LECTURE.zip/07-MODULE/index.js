const path = require('path')
path.mkdir(path.join(__dirname, '대모'));
     if(err) {
         return console.error(err)
     }
     onsole.log('디렉토리 생성완료'); 
