// 파일 생성
const fs = require('fs')
fs.readFileSync('./input.txt', 'UTF-8')
console.log(data);
console.log('파일 읽기 완료');

// fs.readFile('./input.txt','utf-8', function(err, data){
//     console.log(data)
// })
// console.log('파일 읽기 완료')