console.log('최소희');
alert('Hello') // 이건 브라우저에 팝ㅇ넙창을 띄우는 기능이므로 안됨.
// package.json ->  "emoji": "^0.3.2"  버전을 의미