const superHero = 'batman';
console.log(superHero);