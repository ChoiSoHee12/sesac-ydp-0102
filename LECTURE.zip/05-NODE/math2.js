// 함수 선언
// const add = (a,b) => {
//     return a+b
// };

// 생략 가능

const add = (a,b) => a+b;
// add 함수를 다른 js 파일에서 불러와 사용할 수 있도록 내보내기
module.exports = add;