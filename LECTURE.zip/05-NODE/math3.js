const add = (a,b) => a+b;
const PI = 3.141592;
const E = 2.718

module.exports.add =add;
module.exports.PI = PI;
module.exports.E = E;