import add  from './math.mjs';
console.log(add(5,5))

// 이것도 mjs파일