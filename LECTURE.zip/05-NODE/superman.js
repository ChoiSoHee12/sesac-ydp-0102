const superHero = 'superman';
console.log(superHero);